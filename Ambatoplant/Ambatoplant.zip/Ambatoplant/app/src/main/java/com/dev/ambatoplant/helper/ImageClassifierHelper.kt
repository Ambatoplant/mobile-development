package com.dev.ambatoplant.helper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.dev.ambatoplant.R
import org.tensorflow.lite.DataType
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.support.common.ops.CastOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.task.core.BaseOptions
import org.tensorflow.lite.task.vision.classifier.Classifications
import org.tensorflow.lite.task.vision.classifier.ImageClassifier

class ImageClassifierHelper(
    private var threshold: Float = 0.5f,  // Default threshold lebih tinggi untuk akurasi lebih baik
    private var maxResults: Int = 3,
    private val modelName: String = "PlantModel.tflite",
    private val context: Context,
    private val classifierListener: ClassifierListener?
) {

    private var imageClassifier: ImageClassifier? = null

    init {
        setupImageClassifier()
    }

    private fun setupImageClassifier() {
        // Menyiapkan Image Classifier untuk memproses gambar.
        val optionsBuilder = ImageClassifier.ImageClassifierOptions.builder()
            .setScoreThreshold(threshold)  // Set threshold
            .setMaxResults(maxResults)     // Set maxResults

        val baseOptionsBuilder = BaseOptions.builder()

        // Cek apakah perangkat mendukung GPU
        if (CompatibilityList().isDelegateSupportedOnThisDevice) {
            baseOptionsBuilder.useGpu()
        } else {
            baseOptionsBuilder.setNumThreads(4)  // Set jumlah thread untuk CPU jika GPU tidak didukung
        }

        optionsBuilder.setBaseOptions(baseOptionsBuilder.build())

        try {
            // Mencoba membuat image classifier dari file dan opsi yang sudah disiapkan
            imageClassifier = ImageClassifier.createFromFileAndOptions(
                context,
                modelName,  // Pastikan nama model benar dan berada di folder assets
                optionsBuilder.build()
            )
        } catch (e: IllegalStateException) {
            // Jika gagal, beri notifikasi error yang lebih mendetail
            classifierListener?.onError("Failed to initialize image classifier: ${e.message}")
            Log.e(TAG, "Model initialization failed: ${e.message}")
            e.printStackTrace()  // Menampilkan stack trace untuk debugging lebih lanjut
        }
    }

    fun classifyStaticImage(imageUri: Uri) {
        // Mengklasifikasikan gambar yang didapatkan dari imageUri

        // Jika imageClassifier belum disiapkan, inisialisasi terlebih dahulu
        if (imageClassifier == null) {
            setupImageClassifier()
        }

        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(224, 224, ResizeOp.ResizeMethod.BILINEAR))  // Resize gambar agar sesuai dengan input model
            .add(CastOp(DataType.FLOAT32))  // Mengubah gambar menjadi format tensor yang sesuai
            .build()

        // Mengambil gambar dari URI dan memprosesnya
        val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, imageUri)
            ImageDecoder.decodeBitmap(source)
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, imageUri)
        }

        bitmap?.copy(Bitmap.Config.ARGB_8888, true)?.let { bitmap ->
            // Mengonversi Bitmap menjadi TensorImage yang bisa diproses oleh model
            val tensorImage = imageProcessor.process(TensorImage.fromBitmap(bitmap))

            // Mengklasifikasikan gambar dan mendapatkan hasil
            val results = imageClassifier?.classify(tensorImage)

            // Mengirimkan hasil klasifikasi ke listener
            classifierListener?.onResults(results)
        } ?: run {
            // Jika bitmap gagal didapatkan
            classifierListener?.onError("Failed to decode image")
            Log.e(TAG, "Failed to decode image from URI: $imageUri")
        }
    }

    interface ClassifierListener {
        fun onError(error: String)
        fun onResults(results: List<Classifications>?)
    }

    companion object {
        private const val TAG = "ImageClassifierHelper"
    }
}
