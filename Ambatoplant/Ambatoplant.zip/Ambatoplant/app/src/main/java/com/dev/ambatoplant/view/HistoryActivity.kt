package com.dev.ambatoplant.view

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dev.ambatoplant.R
import com.dev.ambatoplant.data.source.local.entity.HistoryEntity
import com.dev.ambatoplant.view.adapter.HistoryAdapter

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var historyAdapter: HistoryAdapter
    private val analysisHistory: MutableList<HistoryEntity> = mutableListOf()

    // Convert to HistoryEntity, adding a unique classificationId


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.rv_history)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize Adapter
        historyAdapter = HistoryAdapter(analysisHistory)
        recyclerView.adapter = historyAdapter

        // Sample data - in real case, load from a database or API

    }



}
