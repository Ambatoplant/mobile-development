package com.dev.ambatoplant.view

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.dev.ambatoplant.R
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.io.File

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Pastikan direktori recents ada
        ensureRecentsDirectoryExists()




    // Set fragment default jika savedInstanceState null
        if (savedInstanceState == null) {
            // Menampilkan HomeFragment saat pertama kali dibuka
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, HomeFragment())
                .commit()
        }

        // Pengaturan Bottom Navigation
        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Menampilkan HomeFragment
                    replaceFragment(HomeFragment())
                    true
                }
                R.id.nav_analisis -> {
                    // Menampilkan AnalysisFragment
                    replaceFragment(AnalysisFragment())
                    true
                }
                R.id.nav_history -> {
                    // Menampilkan HistoryFragment
                    replaceFragment(HistoryFragment())
                    true
                }
                else -> false
            }
        }
    }

    // Fungsi untuk memastikan direktori "recents" ada
    private fun ensureRecentsDirectoryExists() {
        val recentsDir = File(applicationContext.filesDir, "recents")
        if (!recentsDir.exists()) {
            if (recentsDir.mkdirs()) {
                Log.d("Directory", "Recents directory created successfully.")
            } else {
                Log.e("Directory", "Failed to create recents directory.")
            }
        } else {
            Log.d("Directory", "Recents directory already exists.")
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d("ActivityLifecycle", "MainActivity resumed")
    }




    // Fungsi untuk mengganti fragment
    private fun replaceFragment(fragment: Fragment) {
        // Mengecek apakah fragment yang sama sudah ditambahkan
        val fragmentTag = fragment.javaClass.simpleName
        val existingFragment = supportFragmentManager.findFragmentByTag(fragmentTag)

        if (existingFragment == null) {
            // Menggunakan replace() untuk mengganti fragment yang lama
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment, fragmentTag)
                .commit()
        }
    }
}
