package com.dev.ambatoplant.data.source.local.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dev.ambatoplant.data.source.local.entity.HistoryEntity

@Database(entities = [HistoryEntity::class], version = 1, exportSchema = false)
abstract class HistoryDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao  // Mendeklarasikan DAO yang akan digunakan

    companion object {
        @Volatile
        private var INSTANCE: HistoryDatabase? = null

        // Fungsi untuk mendapatkan instance dari HistoryDatabase
        fun getDatabase(context: Context): HistoryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HistoryDatabase::class.java,
                    "history_database"  // Nama database
                ).fallbackToDestructiveMigration()  // Jika migrasi gagal, data akan dihancurkan
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
